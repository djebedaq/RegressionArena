Regression Arena 1.0.0 — release candidate

Read BUYER_GUIDE.md before testing. Use a disposable local place copy.

Local installation: open RegressionArena.rbxmx in Roblox Studio, select its single
RegressionArena Script, then Plugins > Save as Local Plugin. Close the asset
without saving changes. Open a copy of the demo place and install the runner from
the plugin's Setup tab. Load the bundled demonstration plan from Snapshot.

Creator Store upload, after explicit owner approval: select only that plugin
Script, then Publish as Plugin. The ZIP and demonstration place are not plugins.
This bundle does not establish seller approval or authorize publication.

Supported: one initial player; Smoke latejoin to two clients. Server-state checks
only. Up to 16 explicit assertions, one local plan and baseline slot. No guarantee
of finding every bug. Remove the runner before shipping your game. Update by
removing the runner with the old matching plugin before replacing that plugin.

All bundle files are listed with SHA-256 hashes in manifest.json. No developer
fixtures, test scripts, debug tools or remote dependencies are distributed here.
